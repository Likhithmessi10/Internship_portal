import React, { useState } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import { useLanguage } from '../context/LanguageContext';
import { Moon, Sun, Globe, LogOut, ChevronLeft, ChevronRight, Settings } from 'lucide-react';

const Sidebar = ({ isCollapsed, onToggle, onMobileClose }) => {
    const { user, logout } = useAuth();
    const { isDarkMode, toggleTheme } = useTheme();
    const { lang, toggleLanguage } = useLanguage();
    const location = useLocation();
    const [isHovered, setIsHovered] = useState(false);

    const isAdmin = user?.role === 'ADMIN';
    const isHOD = user?.role === 'HOD';
    const isPRTI = user?.role === 'CE_PRTI';

    const getDisplayName = () => {
        if (user?.name) return user.name;
        if (user?.email) return user.email.split('@')[0];
        return 'User';
    };

    const displayName = getDisplayName();

    const menuItems = [
        {
            label: 'Dashboard',
            icon: 'dashboard',
            path: isAdmin ? '/admin/dashboard' : (isPRTI ? '/prti/dashboard' : `/${user?.role?.toLowerCase()}/dashboard`)
        },
        ...(!isPRTI ? [{ label: 'Applications', icon: 'description', path: isHOD ? '/hod/applications' : '/internships/past' }] : []),
        ...(isPRTI ? [{
            label: 'Committee Evaluation',
            icon: 'fact_check',
            path: '/prti/committee',
            highlight: true
        }] : []),
        {
            label: 'Committees',
            icon: 'account_tree',
            path: isHOD ? '/hod/committees' : '/committees'
        },
        {
            label: 'Meetings',
            icon: 'event_available',
            path: isPRTI ? '/prti/meetings' : (isHOD ? '/hod/meetings' : '/meetings')
        },
        {
            label: 'Reports',
            icon: 'assessment',
            path: isPRTI ? '/prti/reports' : (isHOD ? '/hod/reports' : '/reports')
        },
    ];

    return (
        <>
            {/* Backdrop for mobile */}
            {isCollapsed && window.innerWidth < 1024 && (
                <div
                    className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 lg:hidden"
                    onClick={onMobileClose}
                />
            )}

            <aside
                className={`fixed left-0 top-0 h-screen bg-[#0B0F14] border-r border-white/8 backdrop-blur-xl flex flex-col z-50 transition-all duration-500 ease-out ${isCollapsed ? 'w-20' : 'w-72'
                    } ${window.innerWidth < 1024 ? (isCollapsed ? 'translate-x-[-100%]' : 'translate-x-0') : ''}`}
                onMouseEnter={() => setIsHovered(true)}
                onMouseLeave={() => setIsHovered(false)}
            >
                {/* Header with logo */}
                <div className={`px-6 py-8 transition-all duration-300 ${isCollapsed ? 'px-4' : ''}`}>
                    <div className="flex items-center gap-4">
                        <div className="relative">
                            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center shadow-lg shadow-blue-500/25">
                                <img src="/logo.png" alt="AP TRANSCO" className="w-10 h-10 object-contain" />
                            </div>
                            <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-emerald-500 rounded-full border-2 border-[#0B0F14]" />
                        </div>

                        {!isCollapsed && (
                            <div className="flex-1">
                                <h1 className="text-lg font-bold text-white tracking-tight">AP Transco</h1>
                                <p className="text-xs text-gray-500 font-medium">Admin Portal</p>
                            </div>
                        )}
                    </div>
                </div>

                {/* Navigation */}
                <nav className="flex-1 px-4 py-6 space-y-1.5 overflow-y-auto">
                    {menuItems.map((item) => (
                        <NavLink
                            key={item.path}
                            to={item.path}
                            onClick={onMobileClose}
                            className={({ isActive }) =>
                                `relative flex items-center gap-3 px-3 py-3 rounded-xl transition-all duration-200 group no-underline ${isActive
                                    ? 'bg-blue-500/10 text-white'
                                    : 'text-gray-400 hover:text-white hover:bg-white/5'
                                } ${isCollapsed ? 'justify-center' : ''}`
                            }
                        >
                            {({ isActive }) => (
                                <>
                                    {/* Active indicator */}
                                    {isActive && (
                                        <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-8 bg-blue-500 rounded-r-full" />
                                    )}

                                    <span className={`material-symbols-outlined flex-shrink-0 transition-transform duration-200 ${isActive ? 'text-blue-400' : 'group-hover:scale-110'
                                        }`}>
                                        {item.icon}
                                    </span>

                                    {!isCollapsed && (
                                        <span className={`text-sm font-medium transition-colors ${isActive ? 'text-white' : ''
                                            }`}>
                                            {item.label}
                                        </span>
                                    )}

                                    {/* Highlight badge for important items */}
                                    {item.highlight && !isCollapsed && (
                                        <span className="ml-auto px-2 py-0.5 text-xs font-semibold bg-blue-500 text-white rounded-full">
                                            New
                                        </span>
                                    )}
                                </>
                            )}
                        </NavLink>
                    ))}
                </nav>

                {/* Footer section */}
                <div className={`px-4 py-6 border-t border-white/8 transition-all duration-300 ${isCollapsed ? 'px-2' : ''}`}>
                    {/* New Internship Button */}
                    {(isAdmin || isPRTI || isHOD) && (
                        <NavLink
                            to="/internships/new"
                            onClick={onMobileClose}
                            className={`group relative bg-gradient-to-r from-blue-500 to-blue-600 text-white py-3.5 px-4 rounded-xl flex items-center justify-center gap-2 font-semibold shadow-lg shadow-blue-500/25 hover:shadow-blue-500/40 hover:scale-[1.02] transition-all duration-200 text-xs uppercase tracking-wide no-underline ${isCollapsed ? 'px-2' : ''
                                }`}
                        >
                            <span className="material-symbols-outlined text-base flex-shrink-0">add</span>
                            {!isCollapsed && <span>New Internship</span>}

                            {/* Shine effect */}
                            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-700 rounded-xl" />
                        </NavLink>
                    )}

                    {/* User profile and settings */}
                    {!isCollapsed && (
                        <div className="mt-4 pt-4 border-t border-white/8">
                            {/* User profile */}
                            <div className="flex items-center gap-3 p-3 rounded-xl bg-white/5 border border-white/8 mb-3">
                                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center flex-shrink-0 shadow-lg">
                                    <span className="text-sm font-bold text-white">
                                        {displayName.charAt(0).toUpperCase()}
                                    </span>
                                </div>
                                <div className="flex-1 min-w-0">
                                    <p className="text-sm font-semibold text-white truncate">{displayName}</p>
                                    <p className="text-xs text-gray-500 font-medium truncate">
                                        {user?.role?.replace('_', ' ') || 'Role'}
                                    </p>
                                </div>
                            </div>

                            {/* Settings row */}
                            <div className="flex items-center gap-2">
                                <button
                                    onClick={toggleTheme}
                                    className="flex-1 flex items-center justify-center gap-2 p-2.5 rounded-lg bg-white/5 hover:bg-white/10 transition-colors text-gray-400 hover:text-white"
                                    title={isDarkMode ? 'Light Mode' : 'Dark Mode'}
                                >
                                    {isDarkMode ? <Sun size={16} /> : <Moon size={16} />}
                                    <span className="text-xs font-medium">{isDarkMode ? 'Light' : 'Dark'}</span>
                                </button>

                                <button
                                    onClick={toggleLanguage}
                                    className="flex-1 flex items-center justify-center gap-2 p-2.5 rounded-lg bg-white/5 hover:bg-white/10 transition-colors text-gray-400 hover:text-white"
                                    title="Toggle Language"
                                >
                                    <Globe size={16} />
                                    <span className="text-xs font-medium">{lang === 'en' ? 'EN' : 'TE'}</span>
                                </button>

                                <button
                                    className="flex items-center justify-center p-2.5 rounded-lg bg-white/5 hover:bg-white/10 transition-colors text-gray-400 hover:text-white"
                                    title="Settings"
                                >
                                    <Settings size={16} />
                                </button>
                            </div>

                            {/* Logout */}
                            <button
                                onClick={logout}
                                className="w-full mt-3 flex items-center justify-center gap-2 p-2.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 transition-colors text-rose-400 hover:text-rose-300 border border-rose-500/20"
                            >
                                <LogOut size={16} />
                                <span className="text-xs font-semibold">Logout</span>
                            </button>
                        </div>
                    )}
                </div>
            </aside>
        </>
    );
};

export default Sidebar;
