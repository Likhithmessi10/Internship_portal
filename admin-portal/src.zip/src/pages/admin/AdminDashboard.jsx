import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import api from '../../utils/api';
import { useAuth } from '../../context/AuthContext';
import {
    Briefcase, Plus, Download, Trash2,
    Users, TrendingUp, CheckCircle, Clock, ChevronRight,
    Calendar, Filter, X, FileSpreadsheet, Settings, Building2,
    ArrowUpRight, ArrowDownRight, DollarSign, GraduationCap, Award,
    Activity, PieChart as PieChartIcon, BarChart3, Target, Zap
} from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';
import { LineChart, Line, AreaChart, Area, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';

const COLORS = ['#3B82F6', '#8B5CF6', '#10B981', '#F59E0B', '#EF4444', '#EC4899', '#6366F1', '#14B8A6'];

const AdminDashboard = () => {
    const { user } = useAuth();
    const { t } = useLanguage();
    const [stats, setStats] = useState({
        totalInternships: 0,
        activeInternships: 0,
        totalApplications: 0,
        hiredStudents: 0,
        pendingApplications: 0,
        rejectedApplications: 0,
        totalStudents: 0,
        successRate: 0
    });
    const [internships, setInternships] = useState([]);
    const [applicationsData, setApplicationsData] = useState([]);
    const [departmentData, setDepartmentData] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchData = async () => {
            setLoading(true);
            try {
                const [internshipsRes, internsRes] = await Promise.all([
                    api.get('/admin/internships'),
                    api.get('/admin/interns/all')
                ]);

                const allInternships = internshipsRes.data.data || [];
                const allInterns = internsRes.data.data || [];

                const activeInternships = allInternships.filter(i => i.isActive).length;
                const totalApplications = allInternships.reduce((acc, i) => acc + (i.applicationsCount || 0), 0);
                const hiredStudents = allInternships.reduce((acc, i) => acc + (i.hiredCount || 0), 0);
                const pendingApplications = allInternships.reduce((acc, i) =>
                    acc + ((i.applicationsCount || 0) - (i.hiredCount || 0) - (i.rejectedCount || 0)), 0
                );
                const rejectedApplications = allInternships.reduce((acc, i) => acc + (i.rejectedCount || 0), 0);
                const successRate = totalApplications > 0 ? Math.round((hiredStudents / totalApplications) * 100) : 0;

                setStats({
                    totalInternships: allInternships.length,
                    activeInternships,
                    totalApplications,
                    hiredStudents,
                    pendingApplications,
                    rejectedApplications,
                    totalStudents: allInterns.length,
                    successRate
                });

                // Prepare applications over time data (last 6 months)
                const monthlyData = {};
                const now = new Date();
                for (let i = 5; i >= 0; i--) {
                    const date = new Date(now.getFullYear(), now.getMonth() - i, 1);
                    const key = `${date.toLocaleString('default', { month: 'short' })} ${date.getFullYear().toString().slice(-2)}`;
                    monthlyData[key] = 0;
                }

                allInternships.forEach(internship => {
                    const createdAt = new Date(internship.createdAt);
                    const key = `${createdAt.toLocaleString('default', { month: 'short' })} ${createdAt.getFullYear().toString().slice(-2)}`;
                    if (monthlyData[key] !== undefined) {
                        monthlyData[key] += internship.applicationsCount || 0;
                    }
                });

                setApplicationsData(Object.entries(monthlyData).map(([month, applications]) => ({
                    month,
                    applications
                })));

                // Prepare department distribution data
                const deptCount = {};
                allInternships.forEach(internship => {
                    const dept = internship.department || 'Other';
                    deptCount[dept] = (deptCount[dept] || 0) + 1;
                });

                setDepartmentData(Object.entries(deptCount).map(([name, value]) => ({
                    name,
                    value
                })).sort((a, b) => b.value - a.value).slice(0, 6));

                setInternships(allInternships.slice(0, 5));
            } catch (err) {
                console.error('Failed to fetch dashboard data', err);
            } finally {
                setLoading(false);
            }
        };

        fetchData();
    }, []);

    const handleDelete = async (id, title) => {
        if (!window.confirm(`Are you sure you want to delete "${title}"?`)) return;
        try {
            await api.delete(`/admin/internships/${id}`);
            setInternships(prev => prev.filter(i => i.id !== id));
        } catch (err) {
            alert(err.response?.data?.message || 'Failed to delete');
        }
    };

    if (loading) {
        return (
            <div className="flex items-center justify-center h-96">
                <div className="text-center">
                    <div className="w-12 h-12 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
                    <p className="text-gray-400 text-sm">Loading dashboard...</p>
                </div>
            </div>
        );
    }

    return (
        <div className="p-8 space-y-8">
            {/* Header */}
            <div className="flex items-center justify-between">
                <div>
                    <p className="text-sm text-gray-400 font-medium mb-1">Welcome back, {user?.name || user?.email?.split('@')[0]}</p>
                    <h1 className="text-3xl font-bold text-white">Dashboard Overview</h1>
                </div>
                <div className="flex items-center gap-3">
                    <Link
                        to="/admin/reports"
                        className="flex items-center gap-2 px-4 py-2.5 bg-white/5 hover:bg-white/10 border border-white/8 rounded-xl text-sm font-semibold text-white transition-all"
                    >
                        <FileSpreadsheet size={18} />
                        <span>Reports</span>
                    </Link>
                    <Link
                        to="/internships/new"
                        className="flex items-center gap-2 px-6 py-2.5 bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white rounded-xl text-sm font-semibold shadow-lg shadow-blue-500/25 hover:shadow-blue-500/40 transition-all hover:scale-105"
                    >
                        <Plus size={18} />
                        <span>New Internship</span>
                    </Link>
                </div>
            </div>

            {/* Top Analytics Strip */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="bg-gradient-to-br from-blue-500/10 to-blue-600/5 border border-blue-500/20 rounded-xl p-4">
                    <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-lg bg-blue-500/20 flex items-center justify-center">
                                <Users size={20} className="text-blue-400" />
                            </div>
                            <div>
                                <p className="text-xs text-gray-400 font-medium">Total Applications</p>
                                <p className="text-2xl font-bold text-white">{stats.totalApplications}</p>
                            </div>
                        </div>
                        <div className="flex items-center gap-1 text-emerald-400">
                            <ArrowUpRight size={16} />
                            <span className="text-xs font-semibold">12%</span>
                        </div>
                    </div>
                </div>

                <div className="bg-gradient-to-br from-emerald-500/10 to-emerald-600/5 border border-emerald-500/20 rounded-xl p-4">
                    <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-lg bg-emerald-500/20 flex items-center justify-center">
                                <CheckCircle size={20} className="text-emerald-400" />
                            </div>
                            <div>
                                <p className="text-xs text-gray-400 font-medium">Selected Interns</p>
                                <p className="text-2xl font-bold text-white">{stats.hiredStudents}</p>
                            </div>
                        </div>
                        <div className="flex items-center gap-1 text-emerald-400">
                            <ArrowUpRight size={16} />
                            <span className="text-xs font-semibold">24%</span>
                        </div>
                    </div>
                </div>

                <div className="bg-gradient-to-br from-rose-500/10 to-rose-600/5 border border-rose-500/20 rounded-xl p-4">
                    <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-lg bg-rose-500/20 flex items-center justify-center">
                                <X size={20} className="text-rose-400" />
                            </div>
                            <div>
                                <p className="text-xs text-gray-400 font-medium">Rejected</p>
                                <p className="text-2xl font-bold text-white">{stats.rejectedApplications}</p>
                            </div>
                        </div>
                        <div className="flex items-center gap-1 text-rose-400">
                            <ArrowDownRight size={16} />
                            <span className="text-xs font-semibold">5%</span>
                        </div>
                    </div>
                </div>

                <div className="bg-gradient-to-br from-purple-500/10 to-purple-600/5 border border-purple-500/20 rounded-xl p-4">
                    <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-lg bg-purple-500/20 flex items-center justify-center">
                                <Target size={20} className="text-purple-400" />
                            </div>
                            <div>
                                <p className="text-xs text-gray-400 font-medium">Success Rate</p>
                                <p className="text-2xl font-bold text-white">{stats.successRate}%</p>
                            </div>
                        </div>
                        <div className="flex items-center gap-1 text-emerald-400">
                            <ArrowUpRight size={16} />
                            <span className="text-xs font-semibold">8%</span>
                        </div>
                    </div>
                </div>
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <div className="group relative bg-gradient-to-br from-gray-900 to-gray-800 rounded-2xl p-6 border border-white/8 shadow-lg transition-all duration-300 hover:scale-[1.03] hover:shadow-xl hover:shadow-blue-500/10">
                    <div className="flex items-center justify-between mb-5">
                        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center shadow-lg shadow-blue-500/25">
                            <Briefcase size={22} className="text-white" />
                        </div>
                    </div>
                    <div className="space-y-2">
                        <span className="text-xs font-medium text-gray-400 uppercase tracking-wide">Total Internships</span>
                        <p className="text-4xl font-bold text-white tracking-tight leading-none">{stats.totalInternships}</p>
                        <p className="text-xs text-gray-500 font-medium">{stats.activeInternships} active</p>
                    </div>
                </div>

                <div className="group relative bg-gradient-to-br from-gray-900 to-gray-800 rounded-2xl p-6 border border-white/8 shadow-lg transition-all duration-300 hover:scale-[1.03] hover:shadow-xl hover:shadow-purple-500/10">
                    <div className="flex items-center justify-between mb-5">
                        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-500 to-purple-600 flex items-center justify-center shadow-lg shadow-purple-500/25">
                            <Users size={22} className="text-white" />
                        </div>
                    </div>
                    <div className="space-y-2">
                        <span className="text-xs font-medium text-gray-400 uppercase tracking-wide">Total Applications</span>
                        <p className="text-4xl font-bold text-white tracking-tight leading-none">{stats.totalApplications}</p>
                        <p className="text-xs text-gray-500 font-medium">{stats.pendingApplications} pending</p>
                    </div>
                </div>

                <div className="group relative bg-gradient-to-br from-gray-900 to-gray-800 rounded-2xl p-6 border border-white/8 shadow-lg transition-all duration-300 hover:scale-[1.03] hover:shadow-xl hover:shadow-emerald-500/10">
                    <div className="flex items-center justify-between mb-5">
                        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-emerald-500 to-emerald-600 flex items-center justify-center shadow-lg shadow-emerald-500/25">
                            <CheckCircle size={22} className="text-white" />
                        </div>
                    </div>
                    <div className="space-y-2">
                        <span className="text-xs font-medium text-gray-400 uppercase tracking-wide">Hired Students</span>
                        <p className="text-4xl font-bold text-white tracking-tight leading-none">{stats.hiredStudents}</p>
                        <p className="text-xs text-gray-500 font-medium">Successfully placed</p>
                    </div>
                </div>

                <div className="group relative bg-gradient-to-br from-gray-900 to-gray-800 rounded-2xl p-6 border border-white/8 shadow-lg transition-all duration-300 hover:scale-[1.03] hover:shadow-xl hover:shadow-amber-500/10">
                    <div className="flex items-center justify-between mb-5">
                        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-amber-500 to-amber-600 flex items-center justify-center shadow-lg shadow-amber-500/25">
                            <GraduationCap size={22} className="text-white" />
                        </div>
                    </div>
                    <div className="space-y-2">
                        <span className="text-xs font-medium text-gray-400 uppercase tracking-wide">Total Students</span>
                        <p className="text-4xl font-bold text-white tracking-tight leading-none">{stats.totalStudents}</p>
                        <p className="text-xs text-gray-500 font-medium">Active interns</p>
                    </div>
                </div>
            </div>

            {/* Charts Section */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Applications Over Time */}
                <div className="bg-surface rounded-2xl border border-border/50 shadow-lg p-6">
                    <div className="flex items-center justify-between mb-6">
                        <div>
                            <h2 className="text-lg font-semibold text-white">Applications Trend</h2>
                            <p className="text-sm text-gray-400 mt-1">Applications over last 6 months</p>
                        </div>
                        <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center">
                            <Activity size={20} className="text-blue-400" />
                        </div>
                    </div>
                    <ResponsiveContainer width="100%" height={250}>
                        <AreaChart data={applicationsData}>
                            <defs>
                                <linearGradient id="colorApplications" x1="0" y1="0" x2="0" y2="1">
                                    <stop offset="5%" stopColor="#3B82F6" stopOpacity={0.3} />
                                    <stop offset="95%" stopColor="#3B82F6" stopOpacity={0} />
                                </linearGradient>
                            </defs>
                            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                            <XAxis dataKey="month" stroke="#6B7280" fontSize={12} tickLine={false} axisLine={false} />
                            <YAxis stroke="#6B7280" fontSize={12} tickLine={false} axisLine={false} />
                            <Tooltip
                                contentStyle={{
                                    backgroundColor: '#1F2937',
                                    border: '1px solid rgba(255,255,255,0.1)',
                                    borderRadius: '12px',
                                    color: '#fff'
                                }}
                            />
                            <Area
                                type="monotone"
                                dataKey="applications"
                                stroke="#3B82F6"
                                strokeWidth={2}
                                fillOpacity={1}
                                fill="url(#colorApplications)"
                            />
                        </AreaChart>
                    </ResponsiveContainer>
                </div>

                {/* Department Distribution */}
                <div className="bg-surface rounded-2xl border border-border/50 shadow-lg p-6">
                    <div className="flex items-center justify-between mb-6">
                        <div>
                            <h2 className="text-lg font-semibold text-white">Department Distribution</h2>
                            <p className="text-sm text-gray-400 mt-1">Internships by department</p>
                        </div>
                        <div className="w-10 h-10 rounded-xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center">
                            <PieChartIcon size={20} className="text-purple-400" />
                        </div>
                    </div>
                    <ResponsiveContainer width="100%" height={250}>
                        <PieChart>
                            <Pie
                                data={departmentData}
                                cx="50%"
                                cy="50%"
                                innerRadius={60}
                                outerRadius={100}
                                paddingAngle={5}
                                dataKey="value"
                            >
                                {departmentData.map((entry, index) => (
                                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                ))}
                            </Pie>
                            <Tooltip
                                contentStyle={{
                                    backgroundColor: '#1F2937',
                                    border: '1px solid rgba(255,255,255,0.1)',
                                    borderRadius: '12px',
                                    color: '#fff'
                                }}
                            />
                        </PieChart>
                    </ResponsiveContainer>
                    <div className="flex flex-wrap gap-3 mt-4 justify-center">
                        {departmentData.map((entry, index) => (
                            <div key={entry.name} className="flex items-center gap-2">
                                <div
                                    className="w-3 h-3 rounded-full"
                                    style={{ backgroundColor: COLORS[index % COLORS.length] }}
                                />
                                <span className="text-xs text-gray-400">{entry.name}</span>
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            {/* Recent Internships Table */}
            <div className="bg-surface rounded-2xl border border-border/50 shadow-lg overflow-hidden">
                <div className="p-6 border-b border-border/50">
                    <div className="flex items-center justify-between">
                        <div>
                            <h2 className="text-xl font-semibold text-white">Recent Internships</h2>
                            <p className="text-sm text-gray-400 mt-1">Latest internship programs</p>
                        </div>
                        <Link
                            to="/internships"
                            className="flex items-center gap-2 text-sm font-semibold text-blue-400 hover:text-blue-300 transition-colors"
                        >
                            <span>View All</span>
                            <ChevronRight size={16} />
                        </Link>
                    </div>
                </div>

                {internships.length > 0 ? (
                    <div className="overflow-x-auto">
                        <table className="w-full">
                            <thead>
                                <tr className="bg-white/5">
                                    <th className="px-6 py-4 text-left text-xs font-semibold text-gray-400 uppercase tracking-wider">Internship</th>
                                    <th className="px-6 py-4 text-left text-xs font-semibold text-gray-400 uppercase tracking-wider">Department</th>
                                    <th className="px-6 py-4 text-center text-xs font-semibold text-gray-400 uppercase tracking-wider">Applications</th>
                                    <th className="px-6 py-4 text-center text-xs font-semibold text-gray-400 uppercase tracking-wider">Hired</th>
                                    <th className="px-6 py-4 text-center text-xs font-semibold text-gray-400 uppercase tracking-wider">Status</th>
                                    <th className="px-6 py-4 text-right text-xs font-semibold text-gray-400 uppercase tracking-wider">Actions</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-border/50">
                                {internships.map((internship) => {
                                    const fillRate = internship.openingsCount > 0
                                        ? Math.round((internship.hiredCount / internship.openingsCount) * 100)
                                        : 0;

                                    return (
                                        <tr key={internship.id} className="hover:bg-white/5 transition-colors group">
                                            <td className="px-6 py-4">
                                                <div className="flex items-center gap-3">
                                                    <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500/10 to-purple-500/10 border border-blue-500/20 flex items-center justify-center">
                                                        <Briefcase size={20} className="text-blue-400" />
                                                    </div>
                                                    <div>
                                                        <p className="text-sm font-semibold text-white">{internship.title}</p>
                                                        <p className="text-xs text-gray-500 mt-0.5">{internship.location || 'Multiple Locations'}</p>
                                                    </div>
                                                </div>
                                            </td>
                                            <td className="px-6 py-4">
                                                <span className="inline-flex items-center px-3 py-1 rounded-lg bg-white/5 border border-white/8 text-xs font-medium text-gray-300">
                                                    {internship.department}
                                                </span>
                                            </td>
                                            <td className="px-6 py-4 text-center">
                                                <span className="text-sm font-semibold text-white">{internship.applicationsCount}</span>
                                            </td>
                                            <td className="px-6 py-4 text-center">
                                                <div className="flex flex-col items-center gap-2">
                                                    <span className="text-sm font-semibold text-emerald-400">{internship.hiredCount}</span>
                                                    <div className="w-24 bg-white/5 rounded-full h-1.5 overflow-hidden">
                                                        <div className="bg-gradient-to-r from-emerald-500 to-emerald-400 h-full rounded-full transition-all duration-500" style={{ width: `${fillRate}%` }} />
                                                    </div>
                                                </div>
                                            </td>
                                            <td className="px-6 py-4 text-center">
                                                <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold ${internship.isActive
                                                    ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                                                    : 'bg-gray-500/10 text-gray-400 border border-gray-500/20'
                                                    }`}>
                                                    {internship.isActive ? 'Active' : 'Inactive'}
                                                </span>
                                            </td>
                                            <td className="px-6 py-4 text-right">
                                                <div className="flex items-center justify-end gap-2">
                                                    <Link to={`/admin/internships/${internship.id}`} className="p-2 hover:bg-blue-500/10 rounded-lg transition-colors text-gray-400 hover:text-blue-400">
                                                        <span className="material-symbols-outlined text-sm">visibility</span>
                                                    </Link>
                                                    <button onClick={() => handleDelete(internship.id, internship.title)} className="p-2 hover:bg-rose-500/10 rounded-lg transition-colors text-gray-400 hover:text-rose-400">
                                                        <Trash2 size={18} />
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    );
                                })}
                            </tbody>
                        </table>
                    </div>
                ) : (
                    <div className="p-16 text-center">
                        <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-blue-500/10 to-purple-500/10 border border-blue-500/20 flex items-center justify-center mx-auto mb-6">
                            <Briefcase size={40} className="text-blue-400" />
                        </div>
                        <h3 className="text-xl font-semibold text-white mb-3">No Internships Yet</h3>
                        <p className="text-gray-400 text-sm mb-8 max-w-md mx-auto">Get started by creating your first internship program. Once created, you'll see them listed here with all the details.</p>
                        <Link
                            to="/internships/new"
                            className="inline-flex items-center gap-2 px-8 py-3.5 bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white rounded-xl text-sm font-semibold shadow-lg shadow-blue-500/25 hover:shadow-blue-500/40 transition-all hover:scale-105"
                        >
                            <Plus size={18} />
                            <span>Create Your First Internship</span>
                        </Link>
                    </div>
                )}
            </div>
        </div>
    );
};

export default AdminDashboard;
