import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import api from '../../../utils/api';
import { useAuth } from '../../../context/AuthContext';
import {
    TrendingUp, Users, Briefcase, AlertCircle,
    Filter, Activity, Trash2, CheckCircle, Search
} from 'lucide-react';
import StatsDetailModal from '../../../components/ui/StatsDetailModal';

const PrtiDashboard = () => {
    const { user } = useAuth();
    const [stats, setStats] = useState({
        totalDepts: 14,
        activeInterns: 0,
        activePrograms: 0,
        pendingApps: 0
    });
    const [internships, setInternships] = useState([]);
    const [allInterns, setAllInterns] = useState([]);
    const [departments, setDepartments] = useState([]);
    const [loading, setLoading] = useState(true);
    const [selectedStat, setSelectedStat] = useState(null);

    useEffect(() => {
        const fetchData = async () => {
            setLoading(true);
            try {
                const [intRes, internsRes, configRes] = await Promise.all([
                    api.get('/admin/internships'),
                    api.get('/admin/interns/all'),
                    api.get('/admin/config')
                ]);

                const allInts = intRes.data.data || [];
                const liveInts = allInts.filter(i => i.isActive);
                const internsList = internsRes.data.data || [];
                const depts = configRes.data.data?.departments || [];

                setInternships(allInts);
                setAllInterns(internsList);
                setDepartments(depts);
                
                setStats({
                    totalDepts: depts.length || 16,
                    activeInterns: internsList.length,
                    activePrograms: liveInts.length,
                    pendingApps: allInts.reduce((acc, i) => acc + (i.applicationsCount || 0), 0)
                });
            } catch (err) {
                console.error('Failed to fetch dashboard data', err);
            } finally {
                setLoading(false);
            }
        };
        fetchData();
    }, []);

    const handleDelete = async (id, title) => {
        if (!window.confirm(`Are you sure you want to delete "${title}"? This will delete all applications and related data. This action cannot be undone.`)) {
            return;
        }

        try {
            await api.delete(`/admin/internships/${id}`);
            setInternships(prev => prev.filter(i => i.id !== id));
            // Update stats
            setStats(prev => ({
                ...prev,
                activePrograms: prev.activePrograms - 1
            }));
        } catch (err) {
            console.error('Failed to delete internship', err);
            alert(err.response?.data?.message || 'Failed to delete internship');
        }
    };

    if (loading) return (
        <div className="flex items-center justify-center h-64">
            <div className="animate-spin w-10 h-10 border-4 border-primary border-t-transparent rounded-full" />
        </div>
    );

    return (
        <div className="space-y-8">
            {/* Header */}
            <header className="flex flex-col sm:flex-row sm:justify-between sm:items-end gap-4">
                <div>
                    <span className="text-[10px] font-bold tracking-[0.2em] text-outline uppercase mb-1 block">Institutional Coordination</span>
                    <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight" style={{ color: 'var(--color-on-surface)' }}>PRTI Admin Dashboard</h2>
                </div>
                <div className="flex flex-wrap gap-3">
                    <Link to="/prti/reports" className="flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold transition-all" style={{ backgroundColor: 'var(--color-surface-container)', color: 'var(--color-primary)', border: '1px solid var(--color-outline-variant)' }}>
                        <span className="material-symbols-outlined text-sm">download</span> Advanced Export
                    </Link>
                    <Link to="/internships/new" className="flex items-center gap-2 px-6 py-2 text-white rounded-lg text-xs font-bold tracking-widest hover:opacity-90 shadow-md transition-all uppercase" style={{ backgroundColor: 'var(--color-primary)' }}>
                        <span className="material-symbols-outlined text-sm">add</span> New Internship
                    </Link>
                </div>
            </header>

            {/* Metrics Grid — 1 col mobile, 2 col tablet, 4 col desktop */}
            <section className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 sm:gap-6">
                {/* Card 1 — Total Departments */}
                <button 
                    onClick={() => setSelectedStat({ title: 'Total Departments', type: 'DEPARTMENTS', data: departments })}
                    className="p-6 rounded-2xl shadow-sm border flex flex-col justify-between hover:shadow-xl hover:-translate-y-1 transition-all group text-left w-full"
                    style={{ backgroundColor: 'var(--color-surface-container-low)', borderColor: 'var(--color-outline-variant)' }}
                >
                    <div>
                        <span className="text-[10px] font-bold tracking-widest uppercase block mb-2" style={{ color: 'var(--color-outline)' }}>Total Departments</span>
                        <h2 className="text-4xl font-black tracking-tighter group-hover:scale-110 transition-transform origin-left" style={{ color: 'var(--color-on-surface)' }}>{stats.totalDepts}</h2>
                    </div>
                    <div className="mt-4 flex items-center text-[10px] text-emerald-500 font-bold uppercase tracking-wider">
                        <TrendingUp size={12} className="mr-1" />
                        <span>Corporate Structure</span>
                    </div>
                </button>

                {/* Card 2 — Active Interns */}
                <button 
                    onClick={() => setSelectedStat({ title: 'Active Interns', type: 'INTERNS', data: allInterns })}
                    className="p-6 rounded-2xl shadow-sm border flex flex-col justify-between hover:shadow-xl hover:-translate-y-1 transition-all group text-left w-full"
                    style={{ backgroundColor: 'var(--color-surface-container-low)', borderColor: 'var(--color-outline-variant)' }}
                >
                    <div>
                        <span className="text-[10px] font-bold tracking-widest uppercase block mb-2" style={{ color: 'var(--color-outline)' }}>Active Interns</span>
                        <h2 className="text-4xl font-black tracking-tighter group-hover:scale-110 transition-transform origin-left" style={{ color: 'var(--color-on-surface)' }}>{stats.activeInterns}</h2>
                    </div>
                    <div className="mt-4 flex items-center text-[10px] text-emerald-500 font-bold uppercase tracking-wider">
                        <CheckCircle size={12} className="mr-1" />
                        <span>Onboarded Talent</span>
                    </div>
                </button>

                {/* Card 3 — Active Programs */}
                <button 
                    onClick={() => setSelectedStat({ title: 'Active Programs', type: 'PROGRAMS', data: internships.filter(i => i.isActive) })}
                    className="p-6 rounded-2xl shadow-sm border flex flex-col justify-between hover:shadow-xl hover:-translate-y-1 transition-all group text-left w-full"
                    style={{ backgroundColor: 'var(--color-surface-container-low)', borderColor: 'var(--color-outline-variant)' }}
                >
                    <div>
                        <span className="text-[10px] font-bold tracking-widest uppercase block mb-2" style={{ color: 'var(--color-outline)' }}>Active Programs</span>
                        <h2 className="text-4xl font-black tracking-tighter group-hover:scale-110 transition-transform origin-left" style={{ color: 'var(--color-on-surface)' }}>{stats.activePrograms}</h2>
                    </div>
                    <div className="mt-4 flex items-center text-[10px] text-sky-500 font-bold uppercase tracking-wider">
                        <Activity size={12} className="mr-1" />
                        <span>Running Cycles</span>
                    </div>
                </button>

                {/* Card 4 — Pending Pool (visually consistent with others, accent border) */}
                <button 
                    onClick={() => setSelectedStat({ title: 'Pending Pool', type: 'PROGRAMS', data: internships.filter(i => (i.applicationsCount || 0) > 0) })}
                    className="p-6 rounded-2xl shadow-sm border-2 flex flex-col justify-between hover:shadow-xl hover:-translate-y-1 transition-all group text-left w-full"
                    style={{ backgroundColor: 'var(--color-surface-container-low)', borderColor: 'var(--color-primary)' }}
                >
                    <div>
                        <span className="text-[10px] font-bold tracking-widest uppercase block mb-2" style={{ color: 'var(--color-outline)' }}>Pending Pool</span>
                        <h2 className="text-4xl font-black tracking-tighter group-hover:scale-110 transition-transform origin-left" style={{ color: 'var(--color-on-surface)' }}>{stats.pendingApps}</h2>
                    </div>
                    <div className="mt-4 flex items-center text-[10px] font-bold uppercase tracking-wider" style={{ color: 'var(--color-primary)' }}>
                        <AlertCircle size={12} className="mr-1" />
                        <span>Needs HOD Review</span>
                    </div>
                </button>
            </section>

            {/* Main Content Area */}
            <section className="space-y-4">
                <div className="flex flex-col sm:flex-row sm:justify-between sm:items-end gap-2 mb-2">
                    <div>
                        <h3 className="text-xl font-black tracking-tight" style={{ color: 'var(--color-on-surface)' }}>Master Internship Directory</h3>
                        <p className="text-xs font-medium" style={{ color: 'var(--color-outline)' }}>Overseeing {internships.length} Institutional recruitment cycles</p>
                    </div>
                    <button className="transition-colors self-start sm:self-auto" style={{ color: 'var(--color-outline)' }}>
                        <Filter size={18} />
                    </button>
                </div>

                <div className="rounded-2xl overflow-hidden shadow-sm border overflow-x-auto" style={{ backgroundColor: 'var(--color-surface-container-low)', borderColor: 'var(--color-outline-variant)' }}>
                    <table className="w-full text-left border-collapse">
                        <thead>
                            <tr className="border-b" style={{ backgroundColor: 'var(--color-surface-container)' }}>
                                <th className="px-6 py-4 text-[10px] font-bold uppercase tracking-widest text-outline dark:text-slate-300">Program Details</th>
                                <th className="px-6 py-4 text-[10px] font-bold uppercase tracking-widest text-outline text-center">Applicants</th>
                                <th className="px-6 py-4 text-[10px] font-bold uppercase tracking-widest text-outline text-center">Fill Rate</th>
                                <th className="px-6 py-4 text-[10px] font-bold uppercase tracking-widest text-outline text-right">Coordination</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-outline-variant/10">
                            {internships.slice(0, 5).map(int => {
                                const fillRate = int.openingsCount > 0 ? (int.hiredCount / int.openingsCount) * 100 : 0;
                                return (
                                    <tr key={int.id} className="hover:bg-surface-container-lowest/50 transition-colors">
                                        <td className="px-6 py-4">
                                            <div className="flex items-center gap-4">
                                                <div className="w-10 h-10 bg-surface-container-low rounded-xl flex items-center justify-center text-primary">
                                                    <span className="material-symbols-outlined">account_balance</span>
                                                </div>
                                                <div>
                                                    <p className="font-bold text-primary text-sm">{int.title}</p>
                                                    <p className="text-[10px] text-outline font-bold uppercase tracking-tighter">{int.location || 'VARIOUS LOCATIONS'}</p>
                                                </div>
                                            </div>
                                        </td>
                                        <td className="px-6 py-4 text-center">
                                            <div className="flex flex-col">
                                                <span className="text-sm font-bold text-primary">{int.applicationsCount}</span>
                                                <span className="text-[9px] font-bold text-outline uppercase tracking-widest">Pool Size</span>
                                            </div>
                                        </td>
                                        <td className="px-6 py-4">
                                            <div className="w-24 mx-auto">
                                                <div className="flex items-center justify-between mb-1">
                                                    <span className="text-[10px] font-bold text-primary">{Math.round(fillRate)}%</span>
                                                </div>
                                                <div className="w-full bg-surface-container-high h-1 rounded-full overflow-hidden">
                                                    <div className="bg-primary h-full transition-all duration-1000" style={{ width: `${fillRate}%` }} />
                                                </div>
                                            </div>
                                        </td>
                                        <td className="px-6 py-4 text-right">
                                            <div className="flex justify-end gap-2">
                                                <Link
                                                    to="/committees"
                                                    className="flex items-center gap-1.5 px-3 py-1.5 bg-surface-container-low hover:bg-surface-container-high text-[10px] font-bold text-primary rounded-lg transition-all uppercase tracking-widest no-underline"
                                                >
                                                    <Users size={12} /> Committee
                                                </Link>
                                                <button className="p-1.5 hover:bg-surface-container-high rounded-lg text-outline transition-colors"><span className="material-symbols-outlined text-lg">download</span></button>
                                                <button
                                                    onClick={() => handleDelete(int.id, int.title)}
                                                    className="p-1.5 hover:bg-error/10 rounded-lg text-outline hover:text-error transition-colors"
                                                    title="Delete Internship"
                                                >
                                                    <Trash2 size={18} />
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                );
                            })}
                        </tbody>
                    </table>
                    <div className="px-6 py-4 flex items-center justify-between" style={{ backgroundColor: 'var(--color-surface-container-low)' }}>
                        <span className="text-[10px] font-bold text-outline uppercase tracking-widest">Showing {Math.min(5, internships.length)} of {internships.length} Cycles</span>
                        <div className="flex gap-4">
                            <button className="text-[10px] font-bold text-primary uppercase tracking-widest hover:underline">Previous</button>
                            <button className="text-[10px] font-bold text-primary uppercase tracking-widest hover:underline">Next</button>
                        </div>
                    </div>
                </div>
            </section>

            {selectedStat && (
                <StatsDetailModal
                    title={selectedStat.title}
                    type={selectedStat.type}
                    data={selectedStat.data}
                    onClose={() => setSelectedStat(null)}
                />
            )}
        </div>
    );
};

export default PrtiDashboard;
