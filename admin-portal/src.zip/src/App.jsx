import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import Sidebar from './components/Sidebar';
import { AuthProvider, useAuth } from './context/AuthContext';
import ProtectedRoute from './components/ProtectedRoute';
import { useState } from 'react';

// Admin Pages
import AdminLanding from './pages/admin/AdminLanding';
import AdminLogin from './pages/admin/AdminLogin';
import AdminDashboard from './pages/admin/AdminDashboard';
import CreateInternshipForm from './pages/admin/CreateInternship';
import AdminApplicationReview from './pages/admin/AdminApplicationReview';
import AdminRejected from './pages/admin/AdminRejected';
import AdminRegister from './pages/admin/AdminRegister';
import AdminPastInternships from './pages/admin/AdminPastInternships';

import PrtiDashboard from './pages/admin/prti/PrtiDashboard';
import PrtiInterns from './pages/admin/prti/PrtiInterns';
import PrtiMeetings from './pages/admin/prti/PrtiMeetings';
import PrtiReports from './pages/admin/prti/PrtiReports';
import PrtiPermissions from './pages/admin/prti/PrtiPermissions';
import PrtiHealth from './pages/admin/prti/PrtiHealth';
import PrtiAuditLogs from './pages/admin/prti/PrtiAuditLogs';
import PRTICommitteeDashboard from './pages/admin/prti/PRTICommitteeDashboard';
import PRTICommitteeManagement from './pages/admin/prti/PRTICommitteeManagement';
import HodDashboard from './pages/admin/hod/HodDashboard';
import HodApplications from './pages/admin/hod/HodApplications';
import HodCommittees from './pages/admin/hod/HodCommittees';
import HodMeetings from './pages/admin/hod/HodMeetings';
import MentorDashboard from './pages/admin/mentor/MentorDashboard';
import Profile from './pages/admin/Profile';

const AdminLayout = ({ children }) => {
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isMobileOpen, setIsMobileOpen] = useState(false);

  return (
    <div className="min-h-screen transition-colors duration-300" style={{ backgroundColor: 'var(--color-surface)', color: 'var(--color-on-surface)' }}>
      {/* Mobile overlay backdrop */}
      {isMobileOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/50 backdrop-blur-sm lg:hidden"
          onClick={() => setIsMobileOpen(false)}
        />
      )}

      {/* Mobile top bar (visible < lg) */}
      <div className="fixed top-0 left-0 right-0 z-50 h-14 flex items-center justify-between px-4 border-b lg:hidden" style={{ backgroundColor: 'var(--glass-bg)', backdropFilter: 'blur(12px)', borderColor: 'var(--color-outline-variant)' }}>
        <button
          onClick={() => setIsMobileOpen(!isMobileOpen)}
          className="p-2 rounded-xl transition-colors"
          style={{ color: 'var(--color-on-surface)' }}
        >
          <span className="material-symbols-outlined">{isMobileOpen ? 'close' : 'menu'}</span>
        </button>
        <div className="flex items-center gap-2">
          <img src="/logo.png" alt="AP TRANSCO" className="w-8 h-8 object-contain rounded" />
          <span className="text-sm font-black tracking-widest uppercase" style={{ color: 'var(--color-primary)' }}>AP Transco</span>
        </div>
        <div className="w-10" />{/* spacer */}
      </div>

      {/* Sidebar — hidden on mobile unless opened, always visible on lg+ */}
      <div className={`fixed top-0 left-0 h-full z-50 transition-transform duration-300 ${
        isMobileOpen ? 'translate-x-0' : '-translate-x-full'
      } lg:translate-x-0`}>
        <Sidebar 
          isCollapsed={isSidebarCollapsed} 
          onToggle={setIsSidebarCollapsed} 
          onMobileClose={() => setIsMobileOpen(false)} 
        />
      </div>

      {/* Main content — offset by sidebar width on lg+, padded on top for mobile bar */}
      <main className={`min-h-screen transition-all duration-300 pt-14 lg:pt-0 px-4 sm:px-6 lg:px-8 py-6 lg:py-8 ${
        isSidebarCollapsed ? 'lg:ml-20' : 'lg:ml-64'
      }`}>
        {children}
      </main>
    </div>
  );
};

const APTRANSCO_ROLES = ['ADMIN', 'CE_PRTI', 'HOD', 'MENTOR', 'COMMITTEE_MEMBER'];

// Root redirection is handled by AdminLanding directly.

function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          {/* Public Admin Routes */}
          <Route path="/" element={<AdminLanding />} />
          <Route path="/login" element={<AdminLogin />} />
          <Route path="/register" element={<AdminRegister />} />

          {/* Protected Admin Routes */}
          <Route path="/admin/dashboard" element={
            <ProtectedRoute allowedRoles={['ADMIN']}>
              <AdminLayout><AdminDashboard /></AdminLayout>
            </ProtectedRoute>
          } />
          <Route path="/prti/dashboard" element={
            <ProtectedRoute allowedRoles={['CE_PRTI', 'ADMIN']}>
              <AdminLayout><PrtiDashboard /></AdminLayout>
            </ProtectedRoute>
          } />
          <Route path="/prti/interns" element={
            <ProtectedRoute allowedRoles={['CE_PRTI', 'ADMIN']}>
              <AdminLayout><PrtiInterns /></AdminLayout>
            </ProtectedRoute>
          } />
          <Route path="/prti/meetings" element={
            <ProtectedRoute allowedRoles={['CE_PRTI', 'ADMIN']}>
              <AdminLayout><PrtiMeetings /></AdminLayout>
            </ProtectedRoute>
          } />
          <Route path="/prti/reports" element={
            <ProtectedRoute allowedRoles={['CE_PRTI', 'ADMIN']}>
              <AdminLayout><PrtiReports /></AdminLayout>
            </ProtectedRoute>
          } />
          <Route path="/prti/permissions" element={
            <ProtectedRoute allowedRoles={['CE_PRTI', 'ADMIN']}>
              <AdminLayout><PrtiPermissions /></AdminLayout>
            </ProtectedRoute>
          } />
          <Route path="/prti/health" element={
            <ProtectedRoute allowedRoles={['CE_PRTI', 'ADMIN']}>
              <AdminLayout><PrtiHealth /></AdminLayout>
            </ProtectedRoute>
          } />
          <Route path="/prti/audit-logs" element={
            <ProtectedRoute allowedRoles={['CE_PRTI', 'ADMIN']}>
              <AdminLayout><PrtiAuditLogs /></AdminLayout>
            </ProtectedRoute>
          } />
          <Route path="/prti/committee" element={
            <ProtectedRoute allowedRoles={['CE_PRTI', 'COMMITTEE_MEMBER', 'ADMIN']}>
              <AdminLayout><PRTICommitteeDashboard /></AdminLayout>
            </ProtectedRoute>
          } />
          <Route path="/prti/committees/manage" element={
            <ProtectedRoute allowedRoles={['CE_PRTI', 'ADMIN']}>
              <AdminLayout><PRTICommitteeManagement /></AdminLayout>
            </ProtectedRoute>
          } />
          <Route path="/hod/dashboard" element={
            <ProtectedRoute allowedRoles={['HOD', 'ADMIN']}>
              <AdminLayout><HodDashboard /></AdminLayout>
            </ProtectedRoute>
          } />
          <Route path="/hod/applications" element={
            <ProtectedRoute allowedRoles={['HOD', 'ADMIN']}>
              <AdminLayout><HodApplications /></AdminLayout>
            </ProtectedRoute>
          } />
          <Route path="/hod/committees" element={
            <ProtectedRoute allowedRoles={['HOD', 'ADMIN', 'CE_PRTI']}>
              <AdminLayout><HodCommittees /></AdminLayout>
            </ProtectedRoute>
          } />
          <Route path="/committees" element={
            <ProtectedRoute allowedRoles={['ADMIN', 'CE_PRTI']}>
              <AdminLayout><HodCommittees /></AdminLayout>
            </ProtectedRoute>
          } />
          <Route path="/hod/meetings" element={
            <ProtectedRoute allowedRoles={['HOD', 'ADMIN']}>
              <AdminLayout><HodMeetings /></AdminLayout>
            </ProtectedRoute>
          } />
          <Route path="/mentor/dashboard" element={
            <ProtectedRoute allowedRoles={['MENTOR', 'ADMIN']}>
              <AdminLayout><MentorDashboard /></AdminLayout>
            </ProtectedRoute>
          } />
          <Route path="/internships/new" element={
            <ProtectedRoute allowedRoles={['ADMIN', 'CE_PRTI', 'HOD']}>
              <AdminLayout><CreateInternshipForm /></AdminLayout>
            </ProtectedRoute>
          } />
          <Route path="/internships/:id/applications" element={
            <ProtectedRoute allowedRoles={['ADMIN', 'HOD', 'MENTOR', 'COMMITTEE_MEMBER']}>
              <AdminLayout><AdminApplicationReview /></AdminLayout>
            </ProtectedRoute>
          } />
          <Route path="/rejected" element={
            <ProtectedRoute allowedRoles={['ADMIN', 'HOD']}>
              <AdminLayout><AdminRejected /></AdminLayout>
            </ProtectedRoute>
          } />
          <Route path="/internships/past" element={
            <ProtectedRoute allowedRoles={['ADMIN']}>
              <AdminLayout><AdminPastInternships /></AdminLayout>
            </ProtectedRoute>
          } />
          <Route path="/profile" element={
            <ProtectedRoute allowedRoles={['ADMIN', 'CE_PRTI', 'HOD', 'MENTOR', 'COMMITTEE_MEMBER']}>
              <AdminLayout><Profile /></AdminLayout>
            </ProtectedRoute>
          } />

          {/* Catch-all redirect */}
          <Route path="*" element={<Navigate to="/login" replace />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}

export default App;
